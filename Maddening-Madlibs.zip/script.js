function run(){
noun1 = document.getElementById("noun1").value;
noun2 = document.getElementById("noun2").value;
noun3 = document.getElementById("noun3").value;
occ1 = document. getElementById("occ1").value;
verb1 = document.getElementById("verb1").value;
place1 = document.getElementById("place1").value;
verb2 = document.getElementById("verb2").value; //verb with ed//
noun4 = document.getElementById("noun4").value;
verb3 = document.getElementById("verb3").value; //verb with ing//
noun5 = document.getElementById("noun5").value; //plural//
noun6 = document.getElementById("noun6").value;
emo1 = document.getElementById("emo1").value;
 
document.getElementById("madLib").innerHTML ="<p> It was during the battle of " + noun1 +  "when I was running through a " + noun2 + " when a " + noun3 + " went off right next to my platoon. Our " + occ1 + " yelled for us to " + verb1 + " to the nearest " + place1 + " we could find. When we got to the " + place1 + " we " + verb2 + " to start a fire. As we were starting the fire the enemy saw the " + noun4 + " from the fire and started " + verb3 + noun5 + " at us. we all quickly ducked behind the " + noun6 + " at the " + place1 + " and returned fire. We quickly eliminated the enemy and were" + emo1 + " that we had won the battle. </p> <br> <br> <p> please refresh to resubmit. </p>"
}
